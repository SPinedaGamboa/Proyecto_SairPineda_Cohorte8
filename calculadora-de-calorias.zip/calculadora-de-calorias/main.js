const formularioCalculadora = document.getElementById("formulario-calculadora");
const resultado = document.getElementById("resultado");
formularioCalculadora.addEventListener("submit", (e) => {
  e.preventDefault();
  calcularCalorias();
});

function calcularCalorias() {
  aparecerResultado();

  const nombre = document.getElementById("nombre");
  const tipoDocumento = document.getElementById("tipo-documento");
  const documento = document.getElementById("documento");
  const edad = document.getElementById("edad");
  const peso = document.getElementById("peso");
  const altura = document.getElementById("altura");
  const genero = document.querySelector('input[name="genero"]:checked');
  const actividad = document.getElementById("actividad");

  const multiplicadorTMB = {
    peso: 10,
    altura: 6.25,
    edad: 5,
  };

  const documentTypes = {
    CC: "Cédula de ciudadanía",
    CE: "Cédula de extranjería",
    TI: "Tarjeta de identidad",
  };

  if (
    !nombre.value &&
    !tipoDocumento.value &&
    !documento.value &&
    !edad.value &&
    !peso.value &&
    !actividad.value
  ) {
    mostrarMensajeDeError("Por favor rellene todos los campos");
    return;
  } else if (edad.value < 15 || edad.value > 80) {
    mostrarMensajeDeError("La edad ingresada no es valida");
    return;
  }

  let calculoCalorias;

  //Formula hombres: valor actividad x (10 x peso en kg) + (6,25 × altura en cm) - (5 × edad en años) + 5
  //Formula mujeres: valor actividad x (10 x peso en kg) + (6,25 × altura en cm) - (5 × edad en años) - 161
  if (genero.id === "masculino") {
    calculoCalorias =
      actividad.value *
        (multiplicadorTMB.peso * peso.value +
          multiplicadorTMB.altura * altura.value -
          multiplicadorTMB.edad * edad.value) +
      5;
  } else {
    calculoCalorias =
      actividad.value *
        (multiplicadorTMB.peso * peso.value +
          multiplicadorTMB.altura * altura.value -
          multiplicadorTMB.edad * edad.value) -
      161;
  }

  const result = {
    totalCalorias: `${Math.floor(calculoCalorias)} kcal`,
    grupoPoblacional: "",
  };

  if (edad.value >= 15 && edad.value <= 29) result.grupoPoblacional = "Joven";
  else if (edad.value >= 30 && edad.value <= 59)
    result.grupoPoblacional = "Adultos";
  else if (edad.value >= 60) result.grupoPoblacional = "Adultos mayores";

  console.log(tipoDocumento);

  resultado.innerHTML = `
    <div class="card-body d-flex flex-column justify-content-center align-items-center h-100" id="calculo">
        <h5 class="card-title h2">Resultado final 📶</h5>
        <div class="mb-3">
            <p class="bg-dark text-white p-3">
                El paciente <span class="fw-bold">${
                  nombre.value
                }</span> identificado con <span class="fw-bold">${
    documentTypes[tipoDocumento.value]
  } NO.${documento.value}</span>, requiere un total de <span class="fw-bold">${
    result.totalCalorias
  }</span> para el sostenimiento de su TBM.
            </p>
        </div>
        <div class="mb-3">
            <h6>Grupo poblacional: <span class="badge bg-primary">${
              result.grupoPoblacional
            }</span></h6>
        </div>
    </div>

    `;
  // Volver a limpiar variables
  peso.value = null;
  altura.value = null;
  edad.value = null;
  genero.value = null;
  actividad.value = null;
}

function mostrarMensajeDeError(msg) {
  const calculo = document.querySelector("#calculo");
  if (calculo) {
    calculo.remove();
  }

  const divError = document.createElement("div");
  divError.className = "d-flex justify-content-center align-items-center h-100";
  divError.innerHTML = `<span class="alert alert-danger text-center">${msg}</span>`;

  resultado.appendChild(divError);

  setTimeout(() => {
    divError.remove();
    desvanecerResultado();
  }, 5000);
}

// Animaciones
function aparecerResultado() {
  resultado.style.top = "100vh";
  resultado.style.display = "block";

  let distancia = 100;
  let resta = 0.3;
  let id = setInterval(() => {
    resta *= 1.1;
    resultado.style.top = `${distancia - resta}vh`;
    if (resta > 100) {
      clearInterval(id);
    }
  }, 10);
}

function desvanecerResultado() {
  let distancia = 1;

  let id = setInterval(() => {
    distancia *= 2;
    resultado.style.top = `${distancia}vh`;
    if (distancia > 100) {
      clearInterval(id);
      resultado.style.display = "none";
      resultado.style.top = 0;
    }
  }, 10);
}
